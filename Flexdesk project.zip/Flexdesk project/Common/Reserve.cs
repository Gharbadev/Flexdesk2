﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
   public class Reserve
    {
        public int SeatID { get; set; }
        public int UserID { get; set; }
        

        public string Username { get; set; }
        public string  SeatNo { get; set; }
        public string  SeatName { get; set; }
        public DateTime Date { get; set; }
    }
}
