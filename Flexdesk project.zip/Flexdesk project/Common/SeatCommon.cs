﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class SeatCommon
    {

        public int SeatID { get; set; }
        public string  SeatNo { get; set; }
        public string  SeatName { get; set; }
        
    }
}
