When you're on the Login page you can use "admin" as username and "123" as password.
Now you're logged in as an administrator. This means you have all the rights (read & write) and can manage user accounts.

You can create a new user by clicking on the tab "Create User" and choose a username and a password. 
Don't forget to checkout the "IsAdmin" box otherwise you'll create a user with admin role instead of a regular employee user.

As soon as you've saved these credentials you'll be able to log in with these. You can now reserve a seat on a specific date and save your choice.
On the tab "Check Seat" you can see which seats have been reserved on which dates. You can update and/or delete the chosen seats.